MOHAMED ANSARI A — PORTFOLIO WEBSITE
=====================================

FILES
-----
index.html  - Portfolio content and page structure
style.css   - Creative colorful responsive design
script.js   - Mobile navigation and current year

HOW TO RUN ON WINDOWS
---------------------
1. Download and extract mohamed_ansari_portfolio.zip.
2. Open the extracted folder.
3. Double-click index.html.
   The portfolio will open in your default browser.
4. To edit the website, open the folder in Visual Studio Code:
   - Open VS Code.
   - Choose File > Open Folder.
   - Select the extracted mohamed_ansari_portfolio folder.
   - Edit index.html, style.css or script.js.
5. Save your changes and refresh the browser.

OPTIONAL LIVE PREVIEW IN VS CODE
--------------------------------
Install the "Live Server" extension in VS Code.
Right-click index.html and select "Open with Live Server".

PUBLISH FREE WITH GITHUB PAGES
------------------------------
1. Sign in to GitHub.
2. Create a new public repository named:
   mohamed-ansari-portfolio
3. Upload index.html, style.css and script.js to the repository root.
4. Open the repository Settings > Pages.
5. Under Build and deployment, select "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait for GitHub Pages to publish the site. Your website URL will be
   shown in the Pages settings.

BEFORE PUBLISHING
-----------------
- Check your name, email, phone number and social links.
- Add a real photo if you want one: place it in this folder and update
  the profile-avatar element in index.html.
- Add direct links to individual project repositories when available.
- Keep project descriptions accurate. The software testing simulator
  is marked as a project concept / in development.
- Add your resume only if you want it publicly accessible.
- Do not publish private information.

NOTE
----
This is a static front-end portfolio. The contact email and phone links
open the visitor's email or phone application; there is no backend form.
